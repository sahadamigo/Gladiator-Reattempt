﻿using LensMart.Core;
using LensMart.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace LensMart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private  ProductCore productCore;

        public ProductController(ProductCore productCore) 
        {
            this.productCore = productCore;
        }

        [HttpGet]
        [Route("Read")]

        public  List<ProductModel> GetHomeProduct()
         {
            ResponseModel responseModel = new ResponseModel();
           
            try
            {

                var Read = productCore.GetHomeProduct();
                responseModel.Message = "View Product";
                responseModel.Status = true;
               
                return Read;


            }
            catch (Exception ex)
            {
                responseModel.Response = ex.Message;
                responseModel.Message = "failer";
                responseModel.Status = true;
                return null;
            }
            
                 
            
         }

        [HttpGet]
        [Route("FindById")]

       public ResponseModel ProductEditData(int ProductId)
        {
           
            ResponseModel response = new ResponseModel();

            try
            {
                var find = productCore.ProductEditData(ProductId);
                if (find != null)
                {
                    response.Response = find;
                    response.Status = true;
                    response.Message = "Updated";
                    return response;

                }
                response.ErrorMessage = "Not Updated no such Id";
                response.Status = false;
                return response;


            }
            catch (Exception ex)
            {
                response.Response = ex.Message;
                response.ErrorMessage = "failer";
                response.Status = false;
                return response;

            }
        }

        [HttpPost]
        [Route("Create")]

       public ResponseModel ProductSave(ProductModel data)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                var create = productCore.ProductSave(data);
                if (create != null)
                {
                    response.Response = create;
                    response.Status = true;
                    response.Message = "Created";
                    return response;
                }
                response.ErrorMessage = "Not Created";
                response.Status = false;
                return response;
            }
            catch (Exception ex)
            {
                response.Response = ex.Message;
                response.ErrorMessage = "Not Created";
                response.Status = false;
                return response;
            }
        }

        [HttpPut]
        [Route("Update")]
       public  ResponseModel ProudctEditSave(ProductModel data)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                if (data != null)
                {

                    var update = productCore.ProductEditSave(data);
                   
                    
                        response.Response = update;
                        response.Status = true;
                        response.Message = "Update";
                        return response;
                    
                    
                }
                response.ErrorMessage = "failer";
                response.Status = false;
                response.Message = "no such id";
                return response;

            }
            catch (Exception ex)
            {
                response.Response = ex.Message;
                response.ErrorMessage = "Not updated";
                response.Status = false;
                return response;

               
            }
        }

        [HttpDelete]
        [Route("Delete")]

        public ResponseModel DeleteProduct(int ProductId) 
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var delete = productCore.ProductDelete(ProductId);
                if (delete != null)
                {
                    response.Response = delete;
                    response.Status = true;
                    response.Message = " Deleted";
                    return response;
                }
                
                
                    response.ErrorMessage = "Not Deleted";
                    response.Status = false;
                    return response;
               

            }
            catch (Exception ex)
            {
                response.Response= ex.Message;
                response.ErrorMessage = "Not !!!Deleted";
                response.Status = false;
                return response;
            }


        }

        [HttpGet]
        [Authorize]
        [Route("SeeAdmin")]
        public ResponseModel GetHome()
        {
            ResponseModel respo = null;
            try
            {
                 respo = new ResponseModel();
                var Read = productCore.GetProduct();
                if (Read != null)
                {
                    respo.Response = Read.ToList();
                    respo.Message = "SUCESS";
                    respo.Status = true;
                    return respo;
                }
                respo.ErrorMessage = "do not have product";
                respo.Status = false;
                return respo;

            }
            catch (Exception)
            {
                respo = new ResponseModel();

                respo.ErrorMessage = "do not have product";
                respo.Status = false;
                return respo;

            }
        }

    }
}
