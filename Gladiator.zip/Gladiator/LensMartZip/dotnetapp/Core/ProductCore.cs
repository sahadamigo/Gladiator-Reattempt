﻿using LensMart.Context;
using LensMart.Core.Interface;
using LensMart.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace LensMart.Core
{
    public class ProductCore : IProductCore
    {
        public readonly LensContext lensContext;

        public ProductCore(LensContext lensContext)
        {
            this.lensContext = lensContext;
        }


        public List<ProductModel> GetHomeProduct()//read
        {
            try
            {
                return lensContext.ProductTable.ToList();

            }
            catch(Exception) 
            {

                throw;
            }
        }

        public List<ProductModel> GetProduct()//admin
        {
            try
            {
                return lensContext.ProductTable.ToList();

            }
            catch (Exception)
            {

                throw;
            }

        }

        public   string ProductDelete(int ProductId)//delete
        {
            try
            {
                    if(ProductId ==0)
                    {
                    return "ProductId cannot be zero";
                    }

                var delete = lensContext.ProductTable.Find(ProductId);
                if (delete != null)
                {
                    lensContext.ProductTable.Remove(delete);
                    lensContext.SaveChanges();
                    return "Deleted Successfully";
                }
                else
                {
                    return "Give the Correct ProductId";
                }
              
            }
            catch(Exception)
            {

                throw;
            }
        }

        public ProductModel ProductEditData(int ProductId)//find by id
        {
            try
            {
                

                return lensContext.ProductTable.Find(ProductId);
               


            }
            catch (Exception)
            {

                throw;
            }
        }

        public ProductModel ProductSave(ProductModel data)//create 
        {
           
            try
            {
                if (data != null)
                {
                   lensContext.ProductTable.Add(data);
                   lensContext.SaveChanges();
                    return data;
                   
                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        public string ProductEditSave(ProductModel data)//update
        {
            try
            {
                if (data != null)
                {
                    if (data.ProductId == 0)
                    {
                        return "Product id cannot be zero";
                    }

                    var update = lensContext.ProductTable.Find(data.ProductId);
                    if (update != null)
                    {
                        update.imageUrl = data.imageUrl;
                        update.ProductName = data.ProductName;
                        update.Price = data.Price;
                        update.Description = data.Description;
                        update.quantity = data.quantity;
                        lensContext.Update(update);
                        lensContext.SaveChanges();

                        return "SUCCESS";
                    }
                    else
                    {
                        return $"not found{data.ProductName}";
                    }
                }
                else
                {
                    return "something went wrong";
                }
            }
            catch (Exception) 
            {
                throw;
            }
        }
    }
}
