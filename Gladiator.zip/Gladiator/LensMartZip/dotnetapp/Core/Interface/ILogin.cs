﻿using LensMart.Models;

namespace LensMart.Core.Interface
{
    public interface ILogin
    {
        ResponseModel checkUser(LoginModel loginModel);
    }
}
