﻿using LensMart.Models;
using Microsoft.AspNetCore.Mvc;

namespace LensMart.Core.Interface
{
    public interface IProductCore
    {
        List<ProductModel> GetProduct();
        List<ProductModel> GetHomeProduct();

        ProductModel ProductEditData(int ProductId);//find by it

       ProductModel ProductSave(ProductModel data);//create the new

       string ProductEditSave(ProductModel data);//edit the product

      string ProductDelete(int ProductId);//delete the item
    }
}
