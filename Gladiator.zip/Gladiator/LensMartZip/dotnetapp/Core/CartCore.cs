﻿using LensMart.Context;
using LensMart.Core.Interface;
using LensMart.Models;
using Microsoft.CodeAnalysis;
using System.Security.Cryptography;

namespace LensMart.Core
{
    public class CartCore : ICart
    {
        private readonly LensContext context;
        public CartCore(LensContext context)
        {
            this.context = context;
        }

        public ResponseModel AddToCart(int id, int quantity)
        {
            try
            {
                ResponseModel responseModel = new ResponseModel();
                var ExistingItem = context.ProductTable.FirstOrDefault(i => i.ProductId == id);
                if (ExistingItem != null)
                {
                    ExistingItem.quantity += quantity;
                    context.CartTable.Add(new CartModel 
                    { 
                        Quantity = quantity,
                        ProductName = ExistingItem.ProductName,
                        Price = ExistingItem.Price,
                        
                        
                    });
                    context.SaveChanges();
                    responseModel.Response = ExistingItem;
                    responseModel.Status = true;
                    responseModel.Message = "Added";
                    return responseModel;
                    
                }
                else
                {
                    responseModel.ErrorMessage = "Enter valid Id";
                    responseModel.Status = false;   
                    return responseModel;
                }

             }
            catch (Exception)
            {

                throw;
            }
        }
    

        public ResponseModel DeleteCartItem(int id)
        {
            try
            {
                ResponseModel responseModel = new ResponseModel();
                var RemoveItem = context.CartTable.FirstOrDefault(i => i.cartitemId == id);
                if (RemoveItem != null)
                {
                    context.Remove(RemoveItem);
                    context.SaveChanges();
                    responseModel.Status = true;
                    responseModel.Message = "Deleted";
                    return responseModel;
                }
                else
                {
                    responseModel.ErrorMessage = "Enter valid Id";
                    responseModel.Status = false;
                    return responseModel;
                }
            }
            catch(Exception)
            {
                throw;
            }
        }

        public List<CartModel> ShowCart()
        { 
            try
            {
                
                var display = context.CartTable.ToList();
                return display;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
