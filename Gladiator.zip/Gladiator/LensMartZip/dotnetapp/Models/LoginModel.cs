﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using LensMart.Context;

namespace LensMart.Models
{
    public class LoginModel
    {
       
        public string Email { get; set; }
        
        public string Password { get; set; }

    }
}
