import { Component, OnInit } from '@angular/core';
import { admin } from 'src/app/Models/Admin.modal';
import { AdminserviceService } from 'src/app/service/adminservice.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
delete(_t45: admin) {
throw new Error('Method not implemented.');
}
  lensmart:admin[]=[];
  admin: admin={
    productId:'',
    productName: '',
    price: '',
    imageUrl: '',
    quantity: '',
    description: ''
   // productid: ''
  }

  constructor(private adminservice: AdminserviceService){}

  ngOnInit(): void {
  this.getallproducts();
  }
  getallproducts(){
    this.adminservice.getAllProducts()
    .subscribe(
      (response: admin[]) =>{
  this.lensmart=response;
  console.log(response)
  
}
    );
  }

  onSubmit(){
    this.adminservice.Create(this.admin)
    .subscribe(
      (response)=>{
        this.getallproducts();
        this.admin ={
          productId: '',
          productName: '',
          price: '',
          imageUrl: '',
          quantity: '',
          description: ''
        }
      });
  }
  Delete(productId:any)
  {

      this.adminservice.Delete(productId).subscribe((response)=>
      {
        console.log(response);

      })
  }
  
}
