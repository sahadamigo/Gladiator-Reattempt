export class admin{
[x: string]: any;
    productId!:any
    productName!:string;
    price!:string;
    imageUrl!:string;
    quantity!:string;
    description!:string;
}
export class adminid

{
    ProductId! : any;
}